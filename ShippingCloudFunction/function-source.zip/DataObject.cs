namespace ShippingCloudFunction{   
    public class DataObject
    {
    public Shipment Shipment { get; set; }
    public string userId { get; set; }
    }
}